//---------------- ntp client functions
//the ntp client is a small udp client
//

#include <enc28j60.h>
#include <etherShield.h>
#include <ip_arp_udp_tcp.h>
#include <net.h>

#include <avr/pgmspace.h>
#include <stdlib.h>

#include "ntp.h"

// Number of seconds between 1-Jan-1900 and 1-Jan-1970, unix time starts 1970
// and ntp time starts 1900.
#define GETTIMEOFDAY_TO_NTP_OFFSET 2208988800UL

#define NTP_RECHECK_PERIOD 4*60UL*60UL	/* Try recheck at this many seconds */

// WE RELY ON SOME EXTERNAL VARIABLES
extern uint8_t mymac[6]; 
extern uint8_t myip[4];
extern uint8_t gwip[4];
extern EtherShield es;

// Local variables
static uint8_t ntpip[4] = {148,6,0,1};		// NTP server address (148.6.0.1=time.kfki.hu)
// change summer/winter time and your timezone here (utc +1 is Germany, France etc... in winter), unit is hours times 10:
int8_t hours_offset_to_utc=10;  // 20 means 2.0 hours = 2 hours
static uint8_t ntpclientportL=0;
uint32_t lastNTPrequesttime=0UL;

const char arpreqhdr[] PROGMEM ={0,1,8,0,6,4,0,1};
const char ipntpreqhdr[] PROGMEM ={0x45,0,0,0x4c,0,0,0x40,0,0x40,IP_PROTO_UDP_V}; // 0x4c is the total len on ip
const char ntpreqhdr[] PROGMEM ={0xe3,0,4,0xfa,0,1,0,1,0,0}; 
static uint8_t gwmacaddr[6];

// -----------------------------------------------
// ------------------- CODE -------------------
// -----------------------------------------------


// ***************************************
// ********** support routines ***********
// ***************************************

// fill buffer with a prog-mem string
void fill_buf_p(uint8_t *buf,uint16_t len, const prog_char *progmem_s)
{
	while (len){
		*buf= pgm_read_byte(progmem_s);
		buf++;
		progmem_s++;
		len--;
	}
}

// make an arp request
void client_arp_whohas(uint8_t *buf,uint8_t *ip_we_search)
{
	uint8_t i;
	
	for (i=0;i<6;i++){
		buf[ETH_DST_MAC+i]=0xff;
		buf[ETH_SRC_MAC+i]=mymac[i];
	}
	buf[ETH_TYPE_H_P] = ETHTYPE_ARP_H_V;
	buf[ETH_TYPE_L_P] = ETHTYPE_ARP_L_V;
	fill_buf_p(&buf[ETH_ARP_P],8,arpreqhdr);
	for (i=0;i<6;i++){
		buf[ETH_ARP_SRC_MAC_P+i]=mymac[i];
		buf[ETH_ARP_DST_MAC_P+i]=0;
	}
	for (i=0;i<4;i++){
		buf[ETH_ARP_DST_IP_P+i]=*(ip_we_search +i);
		buf[ETH_ARP_SRC_IP_P+i]=myip[i];
	}
	// 0x2a=42=len of packet
	enc28j60PacketSend(0x2a,buf);
}

// store the gw mac addr
// no len check here, you must first call eth_type_is_arp_and_my_ip
uint8_t client_store_gw_mac(uint8_t *buf,uint8_t *gwip)
{
	uint8_t i;
	for (i=0; i<4; i++)
		if(buf[ETH_ARP_SRC_IP_P+i]!=gwip[i])
			return(0);
	for (i=0; i<6; i++) gwmacaddr[i]=buf[ETH_ARP_SRC_MAC_P +i];
	return(1);
}

void fill_ip_hdr_checksum(uint8_t *buf)
{
        uint16_t ck;
        // clear the 2 byte checksum
        buf[IP_CHECKSUM_P]=0;
        buf[IP_CHECKSUM_P+1]=0;
        buf[IP_FLAGS_P]=0x40; // don't fragment
        buf[IP_FLAGS_P+1]=0;  // fragement offset
        buf[IP_TTL_P]=64; // ttl
        // calculate the checksum:
        ck=checksum((uint8_t *)&buf[IP_P], IP_HEADER_LEN,0);
        buf[IP_CHECKSUM_P]=ck>>8;
        buf[IP_CHECKSUM_P+1]=ck& 0xff;
}

// ntp udp packet
// See http://tools.ietf.org/html/rfc958 for details
//
void client_ntp_request(uint8_t *buf,uint8_t *ntpip,uint8_t srcport)
{
	uint8_t i;
	uint16_t ck;
	//
	for (i=0; i<6; i++) {
		buf[ETH_DST_MAC +i]=gwmacaddr[i]; // gw mac in local lan or host mac
		buf[ETH_SRC_MAC +i]=mymac[i];
	}
	buf[ETH_TYPE_H_P] = ETHTYPE_IP_H_V;
	buf[ETH_TYPE_L_P] = ETHTYPE_IP_L_V;
	fill_buf_p(&buf[IP_P],10,ipntpreqhdr);
	for (i=0; i<4; i++){
		buf[IP_DST_P+i]=ntpip[i];
		buf[IP_SRC_P+i]=myip[i];
	}
	fill_ip_hdr_checksum((uint8_t *)buf);
	buf[UDP_DST_PORT_H_P]=0;
	buf[UDP_DST_PORT_L_P]=0x7b; // ntp=123
	buf[UDP_SRC_PORT_H_P]=10;
	buf[UDP_SRC_PORT_L_P]=srcport; // lower 8 bit of src port
	buf[UDP_LEN_H_P]=0;
	buf[UDP_LEN_L_P]=56; // fixed len
	// zero the checksum
	buf[UDP_CHECKSUM_H_P]=0;
	buf[UDP_CHECKSUM_L_P]=0;
	// copy the data:
	// most fields are zero, here we zero everything and fill later
	for (i=0; i<48; i++) buf[UDP_DATA_P+i]=0;
	fill_buf_p(&buf[UDP_DATA_P],10,ntpreqhdr);
	//
	ck=checksum((uint8_t *)&buf[IP_SRC_P], 16 + 48,1);
	buf[UDP_CHECKSUM_H_P]=ck>>8;
	buf[UDP_CHECKSUM_L_P]=ck& 0xff;
	enc28j60PacketSend(90,buf);
}

// process the answer from the ntp server:
// if dstport==0 then accept any port otherwise only answers going to dstport
// return 1 on sucessful processing of answer
uint8_t client_ntp_process_answer(uint8_t *buf,uint32_t *time,uint8_t dstport_l){
	if (dstport_l)
		if (buf[UDP_DST_PORT_L_P]!=dstport_l)
			return(0);
	if (buf[UDP_LEN_H_P]!=0 || buf[UDP_LEN_L_P]!=56 || buf[UDP_SRC_PORT_L_P]!=0x7b)
		// not ntp
		return(0);
	// copy time from the transmit time stamp field:
	*time=((uint32_t)buf[0x52]<<24)|((uint32_t)buf[0x53]<<16)|((uint32_t)buf[0x54]<<8)|((uint32_t)buf[0x55]);
	return(1);
}

// EPOCH = Jan 1 1970 00:00:00
#define	EPOCH_YR	1970
//(24L * 60L * 60L)
#define	SECS_DAY	86400UL  
#define	LEAPYEAR(year)	(!((year) % 4) && (((year) % 100) || !((year) % 400)))
#define	YEARSIZE(year)	(LEAPYEAR(year) ? 366 : 365)

// isleapyear = 0-1
// month=0-11
// return: how many days a month has
uint8_t monthlen(uint8_t isleapyear,uint8_t month){
	if(month==1){
		return(28+isleapyear);
	}
	if (month>6){
		month--;
	}
	if (month%2==1){
		return(30);
	}
	return(31);
}

// Stores num as a minimum 2 long string and a separator; returns end of string
char *timeentry2str(uint16_t num, char *str, char separator)
{
	if (num<10) {
	  *str = '0';
	  utoa(num,str+1,10);
	}
	else {
	  utoa(num,str,10);
	}
	while (*str) str++;
	if ( separator!= 0 ) {
	  *str = separator;
	  str++;
	  *str = 0;
	}
	return(str);
}

// ************************************************
// ********** ntp client "api" routines ***********
// ************************************************

// Init NTP request
// NB: it assumes that we have a working ethernet connection
void init_NTP_client(uint8_t *buf, uint16_t max_buffer_size)
{
	uint8_t	cnt=50;	  /* make at most this many attempts */
	uint16_t plen;
	
	/* Request gateway address info */
	client_arp_whohas(buf,gwip);
	while ( cnt-- ) {
		plen = es.ES_enc28j60PacketReceive(max_buffer_size, buf);
		if ( plen>0 )
			//  GWip reconciled?
			if(eth_type_is_arp_and_my_ip(buf,plen)){
				if (eth_type_is_arp_req(buf)){
					make_arp_answer_from_request(buf);
				}
				if (eth_type_is_arp_reply(buf)){
					if (client_store_gw_mac(buf,gwip)){
						break;
					}
				}
			}
	}
}

// Check if time needs to be re-synced from NTP server and if so send request
// returns 1 if requested new timestamp else 0
uint8_t request_NTP_time_if_needed(uint8_t *buf, uint32_t time)
{
	if ( (lastNTPrequesttime==0UL) /* if never initialized */
		 || ((time-lastNTPrequesttime)>=NTP_RECHECK_PERIOD) ) {
		ntpclientportL++;
		client_ntp_request(buf,ntpip,ntpclientportL);
		lastNTPrequesttime = time;
		return(1);
	}
	return(0);
}

// Process reply from NTP server if that's what we'got
// Reply from NTP server? udp start, src port must be 123 (0x7b):
// return 1 on valid NTP reply, 0 otherwise
uint8_t process_NTP_reply(uint8_t *buf, uint32_t *timeptr)
{
	if (buf[IP_PROTO_P]==IP_PROTO_UDP_V && buf[UDP_SRC_PORT_H_P]==0 && buf[UDP_SRC_PORT_L_P]==0x7b) {
		if (client_ntp_process_answer(buf,timeptr,ntpclientportL)) {
			// convert to unix time:
			if ((*timeptr & 0x80000000UL) == 0) {
				// 7-Feb-2036 @ 06:28:16 UTC it will wrap:
				*timeptr += 2085978496;
			}
			else {
				// from now until 2036:
				*timeptr -= GETTIMEOFDAY_TO_NTP_OFFSET;
			}
			return(1);
		}
	}
	return(0);
}

// time2str -- convert calendar time (sec since 1970) into broken down time
// returns something like "2007-10-19 01:02:21".
// The return values is the minutes as integer.
uint8_t time2str(uint32_t time, char *daytimestr)
{
	uint32_t dayclock;
    uint16_t dayno;
	uint16_t tm_year = EPOCH_YR;
	uint8_t tm_sec,tm_min,tm_hour,tm_wday,tm_mon;
    char *p;

	time += (int32_t)360*(int32_t)hours_offset_to_utc;	// adjust for timezone
	dayclock = time % SECS_DAY;
	dayno = time / SECS_DAY;

	tm_sec = dayclock % 60UL;
	tm_min = (dayclock % 3600UL) / 60;
	tm_hour = dayclock / 3600UL;
	tm_wday = (dayno + 4) % 7;	/* day 0 was a thursday */
	while (dayno >= YEARSIZE(tm_year)) {
		dayno -= YEARSIZE(tm_year);
		tm_year++;
	}
	tm_mon = 0;
	while (dayno >= monthlen(LEAPYEAR(tm_year),tm_mon)) {
		dayno -= monthlen(LEAPYEAR(tm_year),tm_mon);
		tm_mon++;
	}

/* Instead of the very code-expensive:
	sprintf_P(daytimestr,PSTR("%u-%02u-%02u %02u:%02u:%02u"),tm_year,tm_mon+1,dayno+1, tm_hour,tm_min,tm_sec);
we do the following:
*/
	p = daytimestr;
	p = timeentry2str(tm_year,p,'-');
	p = timeentry2str(tm_mon+1,p,'-');
	p = timeentry2str(dayno+1,p,' ');
	p = timeentry2str(tm_hour,p,':');
	p = timeentry2str(tm_min,p,':');
	p = timeentry2str(tm_sec,p,0);
        
    return(tm_min);
}
