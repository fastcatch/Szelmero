#ifndef NTP_H
#define NTP_H

#ifdef __cplusplus
extern "C" {
#endif
/* NTP client API functions */
void init_NTP_client(uint8_t *buf, uint16_t max_buffer_size);
uint8_t request_NTP_time_if_needed(uint8_t *buf, uint32_t time);
uint8_t process_NTP_reply(uint8_t *buf, uint32_t *timeptr);
uint8_t time2str(uint32_t time, char *daytimestr);
#ifdef __cplusplus
}
#endif

#endif /* NTP_H */
